# 📱 DocuGemini Android APK Installation & User Guide

Thank you for downloading **DocuGemini** for Android!

This package contains the **ready-to-install Android APK (`DocuGemini-v1.0.0-release.apk`)** as well as the full Android Studio project source code.

---

## ⚡ Quick 4-Step Installation on Android Phone / Tablet

### Step 1: Locate the APK File
- From this ZIP archive, extract or copy **`DocuGemini-v1.0.0-release.apk`** to your Android device (via USB, Google Drive, WhatsApp, Telegram, or device file manager).

### Step 2: Open the APK on Your Phone
- Open the **Files** or **Downloads** app on your Android phone.
- Tap on **`DocuGemini-v1.0.0-release.apk`**.

### Step 3: Allow "Install Unknown Apps" (If prompted)
- If your phone displays: *"For your security, your phone is not allowed to install unknown apps from this source"*:
  1. Tap **Settings**.
  2. Toggle **Allow from this source** to **ON** (Enabled).
  3. Press the **Back** button.

### Step 4: Complete Installation & Launch
- Tap **Install**.
- Once installed, tap **Open**.
- **DocuGemini** is now ready! You can read PDFs with up to 400 pages, use continuous smooth scroll, perform precision crop-sharing into Gemini AI, track real-time token quotas, and compile multi-page AI responses into phone-ready PDFs!

---

## 🛠️ Included in this ZIP Package

1. **`DocuGemini-v1.0.0-release.apk`**:
   - Ready-to-install standalone Android application package.
   - Includes full offline client engine, PDF.js renderer, responsive touch gestures, and high-performance WebView.

2. **`android/` Directory**:
   - Complete Android Studio project configured with Gradle 8.2 & Android 14 (API 34).
   - Modern Kotlin `MainActivity.kt` with ChromeClient file-picker support for picking PDFs from Android storage or Google Drive.
   - Ready to open directly in **Android Studio** and run `./gradlew assembleRelease` or deploy to connected phones via ADB.

3. **`dist/` Directory**:
   - Production compiled bundle with Tailwind CSS v4, Lucide icons, and optimized JavaScript chunks.

4. **`README.md`**:
   - Architecture overview, configuration tips, and model switching guides.

---

## 🔒 Security & Privacy Notice
- DocuGemini processes documents, PDF rendering, crop captures, and response compilation **100% client-side**.
- Only the cropped region you explicitly send to Gemini is transmitted to the AI endpoint.
